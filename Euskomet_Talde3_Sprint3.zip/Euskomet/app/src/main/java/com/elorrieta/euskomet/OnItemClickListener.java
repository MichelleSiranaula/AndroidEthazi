package com.elorrieta.euskomet;

 public interface OnItemClickListener {
    void onItemClick(Municipio item);
}
