package com.elorrieta.euskomet;

public interface OnItemClickListenerE {
    void onItemClick(EspaciosNaturales item);
}
